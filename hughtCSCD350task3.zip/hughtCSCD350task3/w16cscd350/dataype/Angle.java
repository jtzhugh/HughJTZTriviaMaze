package w16cscd350.dataype;

public class Angle {
	public static final Angle ANGLE_000 = new Angle(0);
	public static final Angle ANGLE_045 = new Angle(45);
	public static final Angle ANGLE_090 = new Angle(90);
	public static final Angle ANGLE_135 = new Angle(135);
	public static final Angle ANGLE_180 = new Angle(180);
	public static final Angle ANGLE_225 = new Angle(225);
	public static final Angle ANGLE_270 = new Angle(270);
	public static final Angle ANGLE_315 = new Angle(315);

	//the angle in the object
	private double myAng = 0;
	public Angle(double angle)
	{
		myAng = normalize(angle);
	}
	public static double normalize(double angle)
	{
		return angle % 360;
	}
	public Angle add(Angle angle)
	{
		return new Angle(this.myAng + angle.myAng);
	}
	public int compareTo(Angle angle)
	{
		return (int)(angle.myAng - this.myAng);
	}
	public double getValue()
	{
		return this.myAng;
	}
	public Angle reciprocate()
	{
		return new Angle(this.myAng + 180);
	}
	public Angle subtract(Angle angle)
	{
		return new Angle(this.myAng - angle.myAng);
	}
	@Override
	public String toString()
	{
		return "" + this.myAng;
	}
}
